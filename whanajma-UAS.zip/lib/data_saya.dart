class DataSaya {
  static String nama = "najma";
  static String gambar = "assets/gambar_saya.jpg";
}
